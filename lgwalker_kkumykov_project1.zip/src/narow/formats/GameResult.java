/**
 * CS4341 - Project 1 Games
 * Professor Neil Heffernan
 * 
 * Lillian Walker
 * Khazhismel Kumykov
 * 
 */
package narow.formats;

public class GameResult {
    public static final int WON = -1;
    public static final int LOST = -2;
    public static final int TIE = -3;
}

