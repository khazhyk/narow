/**
 * CS4341 - Project 1 Games
 * Professor Neil Heffernan
 * 
 * Lillian Walker
 * Khazhismel Kumykov
 * 
 */
package narow.formats;

public class Player {
	public static final int NONE = 0;
	public static final int US = 1;
	public static final int THEM = 2;
}
