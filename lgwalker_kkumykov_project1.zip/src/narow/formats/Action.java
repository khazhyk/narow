/**
 * CS4341 - Project 1 Games
 * Professor Neil Heffernan
 * 
 * Lillian Walker
 * Khazhismel Kumykov
 * 
 */
package narow.formats;

public class Action {
    public static final int PopOut = 0;
    public static final int Place = 1;
}
